package vn.info.getinfodevice;

import android.content.Context;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SimFragment extends Fragment {
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.sim, container, false);
		ListView menuList = (ListView) rootView.findViewById(R.id.list_sim);
		String loc = "LAC: " + getLAC();
		String cid = "CID: " + getCID();
		String imsi = "IMSI: " + getIMSI();
		String simSerialNumber = "Sim S/N: " + getSimSerialNumber();
		String simNumber = "Phone number: " + getSimNumber();
		String list_sim[]= {loc, cid, imsi, simSerialNumber};
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
				R.layout.listitem, R.id.description, list_sim);
		menuList.setAdapter(adapter);
		return rootView;

	}

	public String getLAC() {

		TelephonyManager mTelephony = (TelephonyManager) getActivity()
				.getSystemService(Context.TELEPHONY_SERVICE);
		String mLAC = "";

		final GsmCellLocation location = (GsmCellLocation) mTelephony
				.getCellLocation();
		if (location != null) {
			mLAC = String.valueOf(location.getLac());
		} else {
			mLAC = "Can not dectect location area code";
		}

		return mLAC;
	}

	public String getCID() {

		TelephonyManager mTelephony = (TelephonyManager) getActivity()
				.getSystemService(Context.TELEPHONY_SERVICE);
		String mCID = "";

		final GsmCellLocation location = (GsmCellLocation) mTelephony
				.getCellLocation();
		if (location != null) {
			mCID =String.valueOf(location.getCid());
		} else {
			mCID = "Can not dectect cell ID";
		}

		return mCID;
	}

	public String getSimSerialNumber() {

		TelephonyManager mTelephony = (TelephonyManager) getActivity()
				.getSystemService(Context.TELEPHONY_SERVICE);
		String mSimSerialNumber = mTelephony.getSimSerialNumber();
		if (mSimSerialNumber == null) {
			mSimSerialNumber = "Can not detect Sim Serial Number";
		}
		else
		{
			mSimSerialNumber= mTelephony.getSimSerialNumber();
		}
		return mSimSerialNumber;
	}
	
	public String getSimNumber() {

		TelephonyManager mTelephony = (TelephonyManager) getActivity()
				.getSystemService(Context.TELEPHONY_SERVICE);
		String mSimNumber = mTelephony.getLine1Number();
		if (mSimNumber == null) {
			mSimNumber = "Can not detect Sim Number";
		}
		else
		{
			mSimNumber= mTelephony.getLine1Number();
		}
		return mSimNumber;
	}

	public String getIMSI() {

		TelephonyManager mTelephony = (TelephonyManager) getActivity()
				.getSystemService(Context.TELEPHONY_SERVICE);
		String mIMSI = mTelephony.getSubscriberId();
		if (mTelephony.getSubscriberId() != null) {
			mIMSI = mTelephony.getSubscriberId();
		} else {
			mIMSI = "No Sim card detected.";
		}
		return mIMSI;
	}
}
