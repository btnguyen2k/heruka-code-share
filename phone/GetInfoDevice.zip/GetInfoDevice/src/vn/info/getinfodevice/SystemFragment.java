package vn.info.getinfodevice;

import android.content.Context;
import android.net.wifi.WifiInfo;
import android.net.wifi.WifiManager;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings.Secure;
import android.support.v4.app.Fragment;
import android.telephony.TelephonyManager;
import android.telephony.gsm.GsmCellLocation;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class SystemFragment extends Fragment {
	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		
		View rootView = inflater.inflate(R.layout.system, container, false);
		ListView menuList = (ListView) rootView.findViewById(R.id.list_system);
		String model = "Model: " + Build.MODEL;
		String product = "Product: " + Build.PRODUCT;
		String manufacturer = "Manufacturer: " + Build.MANUFACTURER;
		String board = "Board: " + Build.BOARD;
		String codeName = "Code Name: " + Build.VERSION.CODENAME;
		String incremantal = "Incremental: " + Build.VERSION.INCREMENTAL;
		String sdk = "SDK: " + Build.VERSION.SDK_INT;
		String bootLoader = "Boot Loader: " + Build.BOOTLOADER;
		String display = "Display: " + Build.DISPLAY;
		String hardware = "Hardware :" + Build.HARDWARE;
		String version = "Android Version: " + Build.VERSION.RELEASE;
		String kernelArchitecture = "Kernel Architecture: "
				+ System.getProperty("os.arch");
		String kernelName = "Kernel Name: " + System.getProperty("os.name");
		String kernelVersion = "Kernel Version: "
				+ System.getProperty("os.version");
		String brand = "Brand: " + Build.BRAND;
		String cpuABI = "CPU ABI: " + Build.CPU_ABI;
		String device = "Device: " + Build.DEVICE;
		String fingerPrint = "Finger Print: " + Build.FINGERPRINT;
		String host = "Host: " + Build.HOST;
		String id = "ID: " + Build.ID;
		String radio = "Radio: " + getRadio();
		String tags = "Tags: " + Build.TAGS;
		String type = "Type: " + Build.TYPE;
		String user = "User: " + Build.USER;
		String imei = "IMEI: " + getIMEI();
		String networkName = "NetWork Name: "
				+ getNetWorkName().replace("\"", "");


		String[] list_info = { model, product, manufacturer, board, codeName,
				incremantal, sdk, bootLoader, display, hardware, version,
				kernelArchitecture, kernelName, kernelVersion, brand, cpuABI,
				device, fingerPrint, host, id, radio, tags, type, user, imei,
				networkName };
		ArrayAdapter<String> adapter = new ArrayAdapter<String>(getActivity(),
				R.layout.listitem, R.id.description, list_info);
		menuList.setAdapter(adapter);
		
		setRetainInstance(true);
		return rootView;

	}

	public String getNetWorkName() {
		WifiManager wifiMgr = (WifiManager) getActivity().getSystemService(
				Context.WIFI_SERVICE);
		WifiInfo wifiInfo = wifiMgr.getConnectionInfo();
		String name = wifiInfo.getSSID();
		return name;
	}

	public String getIMEI() {
		TelephonyManager mTelephony = (TelephonyManager) getActivity()
				.getSystemService(Context.TELEPHONY_SERVICE);
		String mIMEI = "";
		if (mTelephony.getDeviceId() != null) {
			mIMEI = mTelephony.getDeviceId();
		} else {
			mIMEI = Secure.getString(getActivity().getApplicationContext()
					.getContentResolver(), Secure.ANDROID_ID);
		}
		return mIMEI;

	}


	public String getRadio() {
		String mRadio = "";
		if (Build.getRadioVersion() != null) {
			mRadio = Build.getRadioVersion();
		} else {
			mRadio = "Not Support";
		}
		return mRadio;
	}
	
}
