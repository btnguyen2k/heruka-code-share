package vn.info.getinfodevice;

import android.content.Intent;
import android.content.IntentFilter;
import android.os.BatteryManager;
import android.os.Bundle;
import android.os.Handler;
import android.provider.Settings.SettingNotFoundException;
import android.support.v4.app.Fragment;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ArrayAdapter;
import android.widget.ListView;

public class BatteryFragement extends Fragment {
	public int m_iLevel = -1;
	public int m_iScale = -1;
	private String[] list_info = null;
	private Handler mHandler;
	private ArrayAdapter<String> adapter = null;

	@Override
	public View onCreateView(LayoutInflater inflater, ViewGroup container,
			Bundle savedInstanceState) {
		View rootView = inflater.inflate(R.layout.battery, container, false);
		if (isAdded()) {
			ListView menuList = (ListView) rootView
					.findViewById(R.id.list_battery);
			String brightness = "Brightness: " + getBrightNess();
			String batteryHeatlh = "Battery: " + iGetLevel() + "%";
			String batteryCharge = "Charging: " + getCharging();
			list_info = new String[] { brightness, batteryHeatlh, batteryCharge };
			mHandler = new Handler();
			mHandler.postDelayed(m_Runnabler, 2000);
			adapter = new ArrayAdapter<String>(getActivity(),
					R.layout.listitem, R.id.description, list_info);
			menuList.setAdapter(adapter);
			setRetainInstance(true);
		}
		return rootView;

	}

	public Runnable m_Runnabler = new Runnable() {
		public void run() {
			refresh();
			BatteryFragement.this.mHandler.postDelayed(m_Runnabler, 2000);
		}
	};

	public float getBrightNess() {
		float curBrightnessValue = 0;
		try {
			curBrightnessValue = android.provider.Settings.System.getInt(
					getActivity().getContentResolver(),
					android.provider.Settings.System.SCREEN_BRIGHTNESS);
		} catch (SettingNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		} catch (NullPointerException ex) {

		}
		return curBrightnessValue;
	}

	public double iGetLevel() {

		Intent batteryIntent = getActivity().getApplicationContext()
				.registerReceiver(null,
						new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
		int rawlevel = batteryIntent.getIntExtra("level", -1);
		double scale = batteryIntent.getIntExtra("scale", -1);
		double level = -1;
		if (rawlevel >= 0 && scale > 0) {
			level = 100 * rawlevel / scale;
		}
		return level;
	}

	public boolean isCharging() {
		Intent intent = getActivity().registerReceiver(null,
				new IntentFilter(Intent.ACTION_BATTERY_CHANGED));
		int plugged = intent.getIntExtra(BatteryManager.EXTRA_PLUGGED, -1);
		return plugged == BatteryManager.BATTERY_PLUGGED_AC
				|| plugged == BatteryManager.BATTERY_PLUGGED_USB;
	}

	public String getCharging() {
		String info = "";
		if (!isCharging()) {
			info = "Device is not charging!";
		} else {
			info = "Device is charging";
		}
		return info;
	}

	public void refresh() {
		if (adapter != null) {
			list_info[0] = "Brightness: " + getBrightNess();
			list_info[1] = "Battery: " + iGetLevel() + "%";
			list_info[2] = "Charging: " + getCharging();
		}
		adapter.notifyDataSetChanged();
	}
}
